# Dokumen Requirements - MyNotesApp

## Pengantar

MyNotesApp adalah aplikasi Flutter sederhana yang dibuat untuk memenuhi tugas praktikum Pertemuan 3 tentang State & Interaksi Pengguna di Flutter. Aplikasi ini mendemonstrasikan penggunaan StatefulWidget, setState(), TextField, dan AnimatedContainer untuk menciptakan pengalaman pengguna yang interaktif dengan animasi yang halus.

## Glosarium

- **MyNotesApp**: Nama aplikasi Flutter yang akan dikembangkan
- **TextField**: Widget Flutter untuk input teks dari pengguna
- **AnimatedContainer**: Widget Flutter yang memberikan animasi otomatis ketika propertinya berubah
- **StatefulWidget**: Widget Flutter yang dapat memiliki state yang berubah
- **setState()**: Method untuk memperbarui state dan memicu rebuild UI
- **UI**: User Interface atau antarmuka pengguna
- **Sapaan**: Teks yang menampilkan "Halo, <nama>!" kepada pengguna

## Requirements

### Requirement 1: Input Nama Pengguna

**User Story:** Sebagai pengguna, saya ingin dapat memasukkan nama saya di aplikasi, sehingga aplikasi dapat mengenali dan menyapa saya secara personal.

#### Acceptance Criteria

1. KETIKA aplikasi dimulai, MAKA MyNotesApp HARUS menampilkan TextField kosong untuk input nama pengguna
2. KETIKA pengguna mengetik di TextField, MAKA MyNotesApp HARUS menyimpan input tersebut dalam state aplikasi
3. KETIKA TextField menerima fokus, MAKA MyNotesApp HARUS menampilkan cursor dan keyboard untuk input
4. KETIKA pengguna memasukkan teks kosong atau hanya spasi, MAKA MyNotesApp HARUS tetap dapat memproses input tersebut

### Requirement 2: Tombol Ubah Tampilan

**User Story:** Sebagai pengguna, saya ingin memiliki tombol yang dapat saya tekan untuk mengubah tampilan aplikasi, sehingga saya dapat melihat efek interaksi dan animasi.

#### Acceptance Criteria

1. KETIKA aplikasi dimulai, MAKA MyNotesApp HARUS menampilkan tombol dengan label "Ubah Tampilan"
2. KETIKA pengguna menekan tombol "Ubah Tampilan", MAKA MyNotesApp HARUS memicu perubahan state menggunakan setState()
3. KETIKA tombol ditekan, MAKA MyNotesApp HARUS merespons dengan feedback visual yang jelas
4. KETIKA tombol ditekan berulang kali, MAKA MyNotesApp HARUS konsisten dalam memberikan respons

### Requirement 3: Tampilan Sapaan Personal

**User Story:** Sebagai pengguna, saya ingin melihat sapaan personal dengan nama yang telah saya masukkan, sehingga saya merasa aplikasi merespons input saya dengan baik.

#### Acceptance Criteria

1. KETIKA tombol "Ubah Tampilan" ditekan, MAKA MyNotesApp HARUS menampilkan teks sapaan "Halo, <nama yang dimasukkan>!"
2. KETIKA nama pengguna kosong, MAKA MyNotesApp HARUS menampilkan sapaan "Halo, !" atau menangani kasus kosong dengan tepat
3. KETIKA nama pengguna berubah dan tombol ditekan lagi, MAKA MyNotesApp HARUS memperbarui sapaan dengan nama yang baru
4. KETIKA sapaan ditampilkan, MAKA MyNotesApp HARUS memastikan teks dapat dibaca dengan jelas

### Requirement 4: Animasi Area Konten

**User Story:** Sebagai pengguna, saya ingin melihat animasi yang halus ketika tampilan berubah, sehingga pengalaman menggunakan aplikasi menjadi lebih menarik dan responsif.

#### Acceptance Criteria

1. KETIKA tombol "Ubah Tampilan" ditekan, MAKA MyNotesApp HARUS mengubah tampilan area konten menggunakan AnimatedContainer
2. KETIKA animasi berjalan, MAKA MyNotesApp HARUS menampilkan transisi yang halus dan tidak terputus-putus
3. KETIKA area konten berubah, MAKA MyNotesApp HARUS mengubah minimal satu properti visual (warna, ukuran, atau posisi)
4. KETIKA animasi selesai, MAKA MyNotesApp HARUS mempertahankan tampilan baru hingga interaksi berikutnya

### Requirement 5: Struktur Layout dan Widget

**User Story:** Sebagai developer, saya ingin aplikasi menggunakan widget Flutter yang tepat sesuai dengan persyaratan teknis, sehingga kode dapat memenuhi standar praktikum.

#### Acceptance Criteria

1. KETIKA aplikasi dibangun, MAKA MyNotesApp HARUS menggunakan StatefulWidget sebagai widget utama
2. KETIKA UI perlu diperbarui, MAKA MyNotesApp HARUS menggunakan setState() untuk memicu rebuild
3. KETIKA layout disusun, MAKA MyNotesApp HARUS menggunakan Column untuk mengatur widget secara vertikal
4. KETIKA interaksi pengguna terjadi, MAKA MyNotesApp HARUS menggunakan GestureDetector atau Button dengan callback onPressed
5. KETIKA animasi diperlukan, MAKA MyNotesApp HARUS menggunakan AnimatedContainer untuk efek visual

### Requirement 6: Responsivitas dan State Management

**User Story:** Sebagai pengguna, saya ingin aplikasi merespons dengan cepat terhadap setiap interaksi saya, sehingga pengalaman penggunaan terasa lancar dan tidak ada delay yang mengganggu.

#### Acceptance Criteria

1. KETIKA pengguna berinteraksi dengan aplikasi, MAKA MyNotesApp HARUS merespons dalam waktu kurang dari 100ms
2. KETIKA state berubah, MAKA MyNotesApp HARUS memperbarui UI secara konsisten tanpa error
3. KETIKA aplikasi berjalan, MAKA MyNotesApp HARUS mempertahankan state selama sesi penggunaan
4. KETIKA terjadi perubahan orientasi atau resize, MAKA MyNotesApp HARUS tetap berfungsi dengan baik