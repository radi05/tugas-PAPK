import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mynotes_app/main.dart';

void main() {
  group('Task 7.2 Validation Tests', () {
    testWidgets('AnimatedContainer should exist and have correct initial properties', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());
      
      // Find the AnimatedContainer
      final animatedContainer = find.byType(AnimatedContainer);
      expect(animatedContainer, findsOneWidget);
      
      // Get the widget and verify properties
      final container = tester.widget<AnimatedContainer>(animatedContainer);
      expect(container.duration, const Duration(seconds: 1));
      expect(container.curve, Curves.easeInOut);
      
      // Verify decoration
      final decoration = container.decoration as BoxDecoration;
      expect(decoration.color, Colors.blue);
      expect(decoration.borderRadius, BorderRadius.circular(12));
    });
    
    testWidgets('AnimatedContainer should change color when button is pressed', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());
      
      // Get initial container
      var container = tester.widget<AnimatedContainer>(find.byType(AnimatedContainer));
      var decoration = container.decoration as BoxDecoration;
      expect(decoration.color, Colors.blue);
      
      // Press the button
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();
      
      // Verify color changed
      container = tester.widget<AnimatedContainer>(find.byType(AnimatedContainer));
      decoration = container.decoration as BoxDecoration;
      expect(decoration.color, Colors.green);
    });
    
    testWidgets('AnimatedContainer should have proper content', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());
      
      // Verify the container has the correct child content
      expect(find.text('Area Konten'), findsOneWidget);
      
      // Verify the text styling
      final textWidget = tester.widget<Text>(find.text('Area Konten'));
      expect(textWidget.style?.color, Colors.white);
      expect(textWidget.style?.fontSize, 16);
      expect(textWidget.style?.fontWeight, FontWeight.bold);
    });
    
    testWidgets('AnimatedContainer should toggle properties correctly', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());
      
      // Press button twice to test toggle
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();
      
      // Verify back to original color
      final container = tester.widget<AnimatedContainer>(find.byType(AnimatedContainer));
      final decoration = container.decoration as BoxDecoration;
      expect(decoration.color, Colors.blue);
    });
    
    testWidgets('AnimatedContainer should have shadow effect', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());
      
      // Get container decoration
      final container = tester.widget<AnimatedContainer>(find.byType(AnimatedContainer));
      final decoration = container.decoration as BoxDecoration;
      
      // Verify shadow exists
      expect(decoration.boxShadow, isNotNull);
      expect(decoration.boxShadow!.length, 1);
      
      final shadow = decoration.boxShadow!.first;
      expect(shadow.blurRadius, 8);
      expect(shadow.offset, const Offset(0, 4));
    });
    
    testWidgets('AnimatedContainer animation properties should be correct', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());
      
      // Get container
      final container = tester.widget<AnimatedContainer>(find.byType(AnimatedContainer));
      
      // Verify animation properties
      expect(container.duration, const Duration(seconds: 1));
      expect(container.curve, Curves.easeInOut);
    });
    
    testWidgets('AnimatedContainer should be centered', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());
      
      // Find the Center widget that wraps AnimatedContainer
      final centerWidget = find.ancestor(
        of: find.byType(AnimatedContainer),
        matching: find.byType(Center),
      );
      expect(centerWidget, findsOneWidget);
    });
    
    testWidgets('AnimatedContainer should have proper border radius', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());
      
      // Get container decoration
      final container = tester.widget<AnimatedContainer>(find.byType(AnimatedContainer));
      final decoration = container.decoration as BoxDecoration;
      
      // Verify border radius
      expect(decoration.borderRadius, BorderRadius.circular(12));
    });
  });
}