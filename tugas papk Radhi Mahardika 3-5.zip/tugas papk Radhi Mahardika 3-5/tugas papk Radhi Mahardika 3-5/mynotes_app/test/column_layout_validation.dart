import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mynotes_app/main.dart';

void main() {
  group('Task 8.1 - Column Layout Validation', () {
    testWidgets('Column should have proper MainAxisAlignment and CrossAxisAlignment', (WidgetTester tester) async {
      await tester.pumpWidget(const MyNotesApp());

      final column = tester.widget<Column>(find.byType(Column));
      
      // Verify MainAxisAlignment is center (Requirement 5.3)
      expect(column.mainAxisAlignment, equals(MainAxisAlignment.center));
      
      // Verify CrossAxisAlignment is stretch for responsive layout
      expect(column.crossAxisAlignment, equals(CrossAxisAlignment.stretch));
    });

    testWidgets('Layout should have proper padding and margin', (WidgetTester tester) async {
      await tester.pumpWidget(const MyNotesApp());

      // Verify SafeArea is used for proper screen boundaries
      expect(find.byType(SafeArea), findsOneWidget);

      // Verify Padding with all-around padding
      final padding = tester.widget<Padding>(find.byType(Padding));
      expect(padding.padding, equals(const EdgeInsets.all(24.0)));
    });

    testWidgets('Column should have proper spacing between widgets', (WidgetTester tester) async {
      await tester.pumpWidget(const MyNotesApp());

      // Verify SizedBox widgets for spacing exist
      final sizedBoxes = tester.widgetList<SizedBox>(find.byType(SizedBox));
      
      // Should have multiple SizedBox widgets for spacing
      expect(sizedBoxes.length, greaterThan(1));
      
      // Verify specific spacing values
      bool hasHeight24 = sizedBoxes.any((box) => box.height == 24);
      bool hasHeight32 = sizedBoxes.any((box) => box.height == 32);
      
      expect(hasHeight24, isTrue, reason: 'Should have SizedBox with height 24');
      expect(hasHeight32, isTrue, reason: 'Should have SizedBox with height 32');
    });

    testWidgets('Column should use Spacer widgets for flexible spacing', (WidgetTester tester) async {
      await tester.pumpWidget(const MyNotesApp());

      // Verify Spacer widgets exist for flexible layout
      final spacers = tester.widgetList<Spacer>(find.byType(Spacer));
      
      // Should have at least 2 Spacer widgets (top and bottom)
      expect(spacers.length, equals(2));
      
      // Verify flex values
      expect(spacers.first.flex, equals(1)); // Top spacer
      expect(spacers.last.flex, equals(2));  // Bottom spacer
    });

    testWidgets('All required widgets should be arranged in Column', (WidgetTester tester) async {
      await tester.pumpWidget(const MyNotesApp());

      // Verify Column exists (Requirement 5.3)
      expect(find.byType(Column), findsOneWidget);

      // Verify all required widgets are present in the layout
      expect(find.byType(TextField), findsOneWidget);
      expect(find.byType(ElevatedButton), findsOneWidget);
      expect(find.byType(AnimatedContainer), findsOneWidget);
    });

    testWidgets('Layout should be responsive and well-structured', (WidgetTester tester) async {
      await tester.pumpWidget(const MyNotesApp());

      // Verify button has proper styling for full width
      final button = tester.widget<ElevatedButton>(find.byType(ElevatedButton));
      expect(button.style, isNotNull);

      // Verify AnimatedContainer is centered
      expect(find.ancestor(
        of: find.byType(AnimatedContainer),
        matching: find.byType(Center),
      ), findsOneWidget);
    });

    testWidgets('TextField should have proper styling and padding', (WidgetTester tester) async {
      await tester.pumpWidget(const MyNotesApp());

      final textField = tester.widget<TextField>(find.byType(TextField));
      
      // Verify TextField has proper decoration
      expect(textField.decoration?.labelText, equals('Masukkan nama Anda'));
      expect(textField.decoration?.border, isA<OutlineInputBorder>());
      
      // Verify content padding
      expect(textField.decoration?.contentPadding, 
        equals(const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0)));
    });

    testWidgets('Button should have proper styling and padding', (WidgetTester tester) async {
      await tester.pumpWidget(const MyNotesApp());

      final button = tester.widget<ElevatedButton>(find.byType(ElevatedButton));
      
      // Verify button text
      expect(find.text('Ubah Tampilan'), findsOneWidget);
      
      // Verify button has proper styling (padding is set in style)
      expect(button.style, isNotNull);
    });
  });
}