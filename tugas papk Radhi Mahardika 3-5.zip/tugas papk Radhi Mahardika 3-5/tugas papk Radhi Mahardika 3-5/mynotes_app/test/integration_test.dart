import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mynotes_app/main.dart';

void main() {
  group('Task 11.1: Component Integration and Wiring Validation', () {
    testWidgets('Complete integration test - all components wired correctly', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());
      
      // 1. Verify initial state and all components are present
      expect(find.text('MyNotesApp'), findsOneWidget, reason: 'App title should be present');
      expect(find.text('Masukkan nama Anda'), findsOneWidget, reason: 'TextField label should be present');
      expect(find.text('Ubah Tampilan'), findsOneWidget, reason: 'Button should be present');
      expect(find.text('Area Konten'), findsOneWidget, reason: 'AnimatedContainer content should be present');
      expect(find.textContaining('Halo,'), findsNothing, reason: 'Greeting should not be visible initially');
      
      // 2. Test TextField → _onNameChanged → _userName state wiring
      const testName = 'Integration Test User';
      await tester.enterText(find.byType(TextField), testName);
      await tester.pump();
      
      // Verify TextField input is captured (we can't directly access state, but we'll verify through greeting)
      
      // 3. Test Button → _onChangeDisplay → state changes wiring
      final animatedContainerFinder = find.byType(AnimatedContainer);
      expect(animatedContainerFinder, findsOneWidget, reason: 'AnimatedContainer should be present');
      
      // Get initial container properties (we'll verify changes after button press)
      final AnimatedContainer initialContainer = tester.widget(animatedContainerFinder);
      
      // Press the button to trigger state changes
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump(); // Trigger immediate state change
      
      // 4. Verify state changes → UI updates wiring
      
      // 4a. Verify greeting appears with correct format (Requirements 3.1)
      expect(find.text('Halo, $testName!'), findsOneWidget, 
        reason: 'Greeting should appear with correct format after button press');
      
      // 4b. Verify AnimatedContainer properties changed (Requirements 4.1)
      final AnimatedContainer updatedContainer = tester.widget(animatedContainerFinder);
      
      // Container decoration should have changed after state change
      final initialDecoration = initialContainer.decoration as BoxDecoration;
      final updatedDecoration = updatedContainer.decoration as BoxDecoration;
      expect(updatedDecoration.color != initialDecoration.color, 
             isTrue, reason: 'AnimatedContainer color should change after button press');
      
      // 5. Test animation progression
      await tester.pump(const Duration(milliseconds: 500)); // Pump animation
      await tester.pumpAndSettle(); // Wait for animation to complete
      
      // Container should still be present and greeting should persist
      expect(find.text('Halo, $testName!'), findsOneWidget, 
        reason: 'Greeting should persist after animation');
      expect(find.byType(AnimatedContainer), findsOneWidget, 
        reason: 'AnimatedContainer should persist after animation');
      
      // 6. Test multiple interactions to verify consistent wiring
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();
      await tester.pumpAndSettle();
      
      // Greeting should still be there (Requirements 2.4)
      expect(find.text('Halo, $testName!'), findsOneWidget, 
        reason: 'Greeting should persist after multiple button presses');
      
      // 7. Test name change and re-trigger to verify complete wiring
      const newTestName = 'Updated User';
      await tester.enterText(find.byType(TextField), newTestName);
      await tester.pump();
      
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();
      
      // Should show updated greeting (Requirements 3.3)
      expect(find.text('Halo, $newTestName!'), findsOneWidget, 
        reason: 'Greeting should update with new name');
      expect(find.text('Halo, $testName!'), findsNothing, 
        reason: 'Old greeting should be replaced');
    });
    
    testWidgets('Event handler wiring validation', (WidgetTester tester) async {
      await tester.pumpWidget(const MyNotesApp());
      
      // Test TextField onChanged wiring
      await tester.enterText(find.byType(TextField), 'Handler Test');
      await tester.pump();
      
      // Test Button onPressed wiring
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();
      
      // Verify both handlers worked together
      expect(find.text('Halo, Handler Test!'), findsOneWidget,
        reason: 'Both TextField and Button handlers should work together');
    });
    
    testWidgets('State consistency across UI updates', (WidgetTester tester) async {
      await tester.pumpWidget(const MyNotesApp());
      
      // Test sequence: input → button → input → button
      await tester.enterText(find.byType(TextField), 'State Test 1');
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();
      expect(find.text('Halo, State Test 1!'), findsOneWidget);
      
      await tester.enterText(find.byType(TextField), 'State Test 2');
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();
      expect(find.text('Halo, State Test 2!'), findsOneWidget);
      expect(find.text('Halo, State Test 1!'), findsNothing);
    });
    
    testWidgets('AnimatedContainer state changes validation', (WidgetTester tester) async {
      await tester.pumpWidget(const MyNotesApp());
      
      final containerFinder = find.byType(AnimatedContainer);
      
      // Get initial state
      AnimatedContainer container = tester.widget(containerFinder);
      final initialDecoration = container.decoration as BoxDecoration?;
      final initialColor = initialDecoration?.color;
      
      // Trigger state change
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();
      
      // Get updated state
      container = tester.widget(containerFinder);
      final updatedDecoration = container.decoration as BoxDecoration?;
      final updatedColor = updatedDecoration?.color;
      
      // Verify changes occurred
      expect(updatedColor != initialColor, isTrue, 
        reason: 'Container color should change');
      
      // Trigger another change
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();
      
      container = tester.widget(containerFinder);
      final secondDecoration = container.decoration as BoxDecoration?;
      final secondColor = secondDecoration?.color;
      
      // Verify toggle behavior
      expect(secondColor != updatedColor, isTrue, 
        reason: 'Container should toggle back');
    });
    
    testWidgets('Requirements validation - all requirements met', (WidgetTester tester) async {
      await tester.pumpWidget(const MyNotesApp());
      
      // Requirement 1.2: Input tersimpan dalam state
      await tester.enterText(find.byType(TextField), 'Req Test');
      await tester.pump();
      
      // Requirement 2.2: Button memicu setState()
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();
      
      // Requirement 3.1: Sapaan muncul dengan format benar
      expect(find.text('Halo, Req Test!'), findsOneWidget,
        reason: 'Requirement 3.1: Greeting format should be correct');
      
      // Requirement 4.1: AnimatedContainer berubah
      expect(find.byType(AnimatedContainer), findsOneWidget,
        reason: 'Requirement 4.1: AnimatedContainer should be present and changing');
      
      // Requirement 5.1: StatefulWidget digunakan
      expect(find.byType(MyNotesHomePage), findsOneWidget,
        reason: 'Requirement 5.1: StatefulWidget should be used');
      
      // Requirement 6.2: UI update konsisten
      await tester.enterText(find.byType(TextField), 'Consistency Test');
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();
      expect(find.text('Halo, Consistency Test!'), findsOneWidget,
        reason: 'Requirement 6.2: UI updates should be consistent');
    });
    
    testWidgets('Edge cases integration', (WidgetTester tester) async {
      await tester.pumpWidget(const MyNotesApp());
      
      // Test empty input
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();
      expect(find.text('Halo, !'), findsOneWidget,
        reason: 'Empty input should be handled gracefully');
      
      // Test whitespace input
      await tester.enterText(find.byType(TextField), '   ');
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();
      expect(find.text('Halo,    !'), findsOneWidget,
        reason: 'Whitespace input should be handled gracefully');
      
      // Test special characters
      await tester.enterText(find.byType(TextField), 'José-María@123');
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();
      expect(find.text('Halo, José-María@123!'), findsOneWidget,
        reason: 'Special characters should be handled correctly');
    });
  });
}