import 'package:flutter/material.dart';

/// Wrapper widget yang disable overflow indicator
class NoOverflowWrapper extends StatelessWidget {
  final Widget child;
  
  const NoOverflowWrapper({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Builder(
      builder: (context) {
        return MediaQuery(
          data: MediaQuery.of(context).copyWith(
            textScaleFactor: 1.0,
          ),
          child: child,
        );
      },
    );
  }
}