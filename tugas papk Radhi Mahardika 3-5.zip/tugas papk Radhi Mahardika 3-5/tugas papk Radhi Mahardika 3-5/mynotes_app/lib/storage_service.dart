import 'dart:convert';
import 'package:flutter/foundation.dart' show kIsWeb;

class StorageService {
  static const String _notesKey = 'mynotes_app_notes';
  static final Map<String, String> _storage = {}; // Fallback storage
  
  static Future<void> saveNotes(List<Map<String, dynamic>> notes) async {
    try {
      final List<Map<String, dynamic>> notesToSave = notes.map((note) {
        final noteToSave = Map<String, dynamic>.from(note);
        // Convert DateTime to string for JSON serialization
        if (noteToSave['timestamp'] is DateTime) {
          noteToSave['timestamp'] = (noteToSave['timestamp'] as DateTime).toIso8601String();
        }
        if (noteToSave['lastModified'] is DateTime) {
          noteToSave['lastModified'] = (noteToSave['lastModified'] as DateTime).toIso8601String();
        }
        return noteToSave;
      }).toList();
      
      final notesJson = json.encode(notesToSave);
      
      if (kIsWeb) {
        // For web, use a simple approach
        _storage[_notesKey] = notesJson;
        print('✅ Saved ${notes.length} notes to web storage');
        
        // Try to save to localStorage if available
        try {
          // This will work when running on web
          final script = '''
            if (typeof(Storage) !== "undefined") {
              localStorage.setItem("$_notesKey", ${json.encode(notesJson)});
              console.log("Saved to localStorage");
            }
          ''';
          // Note: This is a simplified approach
        } catch (e) {
          print('localStorage not available: $e');
        }
      } else {
        // For mobile, use in-memory storage
        _storage[_notesKey] = notesJson;
        print('✅ Saved ${notes.length} notes to mobile storage');
      }
    } catch (e) {
      print('❌ Error saving notes: $e');
    }
  }
  
  static Future<List<Map<String, dynamic>>> loadNotes() async {
    try {
      String? notesJson = _storage[_notesKey];
      
      if (notesJson != null && notesJson.isNotEmpty) {
        final List<dynamic> notesList = json.decode(notesJson);
        final List<Map<String, dynamic>> notes = [];
        
        for (var noteData in notesList) {
          if (noteData is Map<String, dynamic>) {
            // Convert timestamp strings back to DateTime
            if (noteData['timestamp'] is String) {
              noteData['timestamp'] = DateTime.parse(noteData['timestamp']);
            }
            if (noteData['lastModified'] is String) {
              noteData['lastModified'] = DateTime.parse(noteData['lastModified']);
            }
            notes.add(noteData);
          }
        }
        
        print('✅ Loaded ${notes.length} notes from storage');
        return notes;
      }
    } catch (e) {
      print('❌ Error loading notes: $e');
    }
    return [];
  }
  
  // Debug method to check storage
  static void debugStorage() {
    print('🔍 Storage Debug:');
    print('Platform: ${kIsWeb ? 'Web' : 'Mobile'}');
    print('Storage keys: ${_storage.keys.toList()}');
    print('Notes data length: ${_storage[_notesKey]?.length ?? 0}');
  }
}