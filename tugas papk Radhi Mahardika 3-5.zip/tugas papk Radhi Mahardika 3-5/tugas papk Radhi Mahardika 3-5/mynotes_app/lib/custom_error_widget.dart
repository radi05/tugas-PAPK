import 'package:flutter/material.dart';

/// Custom error widget yang tidak menampilkan overflow indicator
class CustomErrorWidget {
  static void setupCustomErrorWidget() {
    ErrorWidget.builder = (FlutterErrorDetails errorDetails) {
      return Container(
        color: Colors.transparent,
        child: const Center(
          child: Text(
            '',
            style: TextStyle(color: Colors.transparent),
          ),
        ),
      );
    };
  }
}