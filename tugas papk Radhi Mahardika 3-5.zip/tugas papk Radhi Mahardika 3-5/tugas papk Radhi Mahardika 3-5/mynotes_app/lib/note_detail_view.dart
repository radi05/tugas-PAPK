import 'package:flutter/material.dart';

/// Halaman Detail Catatan
/// Menampilkan detail catatan yang dipilih dari daftar
class NoteDetailView extends StatelessWidget {
  final Map<String, dynamic> note;

  const NoteDetailView({
    super.key,
    required this.note,
  });

  @override
  Widget build(BuildContext context) {
    final noteData = note['note'] ?? note; // Handle both formats
    final noteIndex = note['index'];
    
    return Scaffold(
      appBar: AppBar(
        title: Text(noteData['title'] ?? 'Detail Catatan'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        actions: [
          IconButton(
            onPressed: () {
              // Navigate to edit page
              Navigator.pop(context, {'action': 'edit'});
            },
            icon: const Icon(Icons.edit),
            tooltip: 'Edit Catatan',
          ),
          IconButton(
            onPressed: () {
              // Tampilkan dialog konfirmasi hapus
              _showDeleteDialog(context);
            },
            icon: const Icon(Icons.delete),
            tooltip: 'Hapus Catatan',
          ),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Judul catatan
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.title, color: Colors.blue),
                          const SizedBox(width: 8),
                          const Text(
                            'Judul:',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        noteData['title'] ?? 'Tanpa Judul',
                        style: const TextStyle(fontSize: 18),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              
              // Konten catatan
              Expanded(
                child: Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            const Icon(Icons.note, color: Colors.green),
                            const SizedBox(width: 8),
                            const Text(
                              'Isi Catatan:',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Expanded(
                          child: SingleChildScrollView(
                            child: Text(
                              noteData['content'] ?? 'Tidak ada konten',
                              style: const TextStyle(fontSize: 16),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              
              // Informasi timestamp
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.access_time, color: Colors.orange),
                          const SizedBox(width: 8),
                          const Text(
                            'Dibuat:',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            _formatDateTime(noteData['timestamp']),
                            style: const TextStyle(color: Colors.grey),
                          ),
                        ],
                      ),
                      if (noteData['lastModified'] != null) ...[
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            const Icon(Icons.edit, color: Colors.blue, size: 20),
                            const SizedBox(width: 8),
                            const Text(
                              'Diperbarui:',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(width: 8),
                            Text(
                              _formatDateTime(noteData['lastModified']),
                              style: const TextStyle(color: Colors.grey),
                            ),
                          ],
                        ),
                      ],
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              
              // Tombol kembali
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.arrow_back),
                  label: const Text('Kembali'),
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16.0),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Format DateTime menjadi string yang mudah dibaca
  String _formatDateTime(dynamic timestamp) {
    if (timestamp == null) return 'Tidak diketahui';
    
    if (timestamp is DateTime) {
      return '${timestamp.day}/${timestamp.month}/${timestamp.year} ${timestamp.hour}:${timestamp.minute.toString().padLeft(2, '0')}';
    }
    
    return timestamp.toString();
  }

  /// Tampilkan dialog konfirmasi hapus
  void _showDeleteDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Hapus Catatan'),
          content: const Text('Apakah Anda yakin ingin menghapus catatan ini?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Batal'),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(context); // Tutup dialog
                Navigator.pop(context, 'delete'); // Kembali dengan flag delete
              },
              style: TextButton.styleFrom(foregroundColor: Colors.red),
              child: const Text('Hapus'),
            ),
          ],
        );
      },
    );
  }
}