import 'dart:convert';
import 'package:flutter/foundation.dart' show kIsWeb;

class StorageServiceSimple {
  static const String _notesKey = 'mynotes_app_notes';
  static final Map<String, String> _memoryStorage = {};
  
  static Future<void> saveNotes(List<Map<String, dynamic>> notes) async {
    try {
      final List<Map<String, dynamic>> notesToSave = notes.map((note) {
        final noteToSave = Map<String, dynamic>.from(note);
        // Convert DateTime to string for JSON serialization
        if (noteToSave['timestamp'] is DateTime) {
          noteToSave['timestamp'] = (noteToSave['timestamp'] as DateTime).toIso8601String();
        }
        if (noteToSave['lastModified'] is DateTime) {
          noteToSave['lastModified'] = (noteToSave['lastModified'] as DateTime).toIso8601String();
        }
        return noteToSave;
      }).toList();
      
      final notesJson = json.encode(notesToSave);
      
      // Save to memory storage (works on all platforms)
      _memoryStorage[_notesKey] = notesJson;
      
      print('✅ Saved ${notes.length} notes to storage');
      print('📊 Storage size: ${notesJson.length} characters');
      
      // Debug: Print first note title if exists
      if (notes.isNotEmpty) {
        print('📝 First note: ${notes.first['title']}');
      }
      
    } catch (e) {
      print('❌ Error saving notes: $e');
    }
  }
  
  static Future<List<Map<String, dynamic>>> loadNotes() async {
    try {
      final notesJson = _memoryStorage[_notesKey];
      
      print('🔍 Loading notes...');
      print('📊 Storage data: ${notesJson?.length ?? 0} characters');
      
      if (notesJson != null && notesJson.isNotEmpty) {
        final List<dynamic> notesList = json.decode(notesJson);
        final List<Map<String, dynamic>> notes = [];
        
        for (var noteData in notesList) {
          if (noteData is Map<String, dynamic>) {
            // Convert timestamp strings back to DateTime
            if (noteData['timestamp'] is String) {
              noteData['timestamp'] = DateTime.parse(noteData['timestamp']);
            }
            if (noteData['lastModified'] is String) {
              noteData['lastModified'] = DateTime.parse(noteData['lastModified']);
            }
            notes.add(noteData);
          }
        }
        
        print('✅ Loaded ${notes.length} notes from storage');
        
        // Debug: Print loaded note titles
        for (int i = 0; i < notes.length; i++) {
          print('📝 Note ${i + 1}: ${notes[i]['title']}');
        }
        
        return notes;
      } else {
        print('📭 No notes found in storage');
      }
    } catch (e) {
      print('❌ Error loading notes: $e');
    }
    return [];
  }
  
  // Debug method
  static void debugStorage() {
    print('🔍 === STORAGE DEBUG ===');
    print('Platform: ${kIsWeb ? 'Web' : 'Mobile'}');
    print('Storage keys: ${_memoryStorage.keys.toList()}');
    print('Notes data exists: ${_memoryStorage.containsKey(_notesKey)}');
    print('Notes data length: ${_memoryStorage[_notesKey]?.length ?? 0}');
    
    if (_memoryStorage[_notesKey] != null) {
      try {
        final data = json.decode(_memoryStorage[_notesKey]!);
        print('Parsed notes count: ${data.length}');
      } catch (e) {
        print('Error parsing stored data: $e');
      }
    }
    print('======================');
  }
  
  // Clear storage (for testing)
  static void clearStorage() {
    _memoryStorage.clear();
    print('🗑️ Storage cleared');
  }
}